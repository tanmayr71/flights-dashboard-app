import React from "react";
import { ArrowRight, AlertTriangle } from "lucide-react";
import type { Flight, FlightStatus } from "@myproj/shared";

/* Tailwind badge styles keyed by status */
const statusBadge: Record<FlightStatus, string> = {
  "On Time":        "bg-green-100 text-green-800",
  Boarding:         "bg-blue-100 text-blue-800",
  Boarded:          "bg-indigo-100 text-indigo-800",
  Departed:         "bg-gray-200 text-gray-800",
  Delayed:          "bg-yellow-200 text-yellow-800",
  "Late Departure": "bg-orange-200 text-orange-800",
  Cancelled:        "bg-red-200 text-red-800",
};

interface Props { flight: Flight }

const FlightCard: React.FC<Props> = ({ flight }) => {
  const dep = new Date(flight.departureTime).toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit",
  });
  const arr = new Date(flight.arrivalTime).toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit",
  });

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-4 flex items-center justify-between">
      {/* left block – times & route */}
      <div>
        <div className="flex items-center gap-2 font-medium text-gray-800">
          <span>{dep}</span>
          <ArrowRight size={16} className="text-gray-500" />
          <span>{arr}</span>
        </div>
        <div className="text-sm text-gray-600">
          {flight.departureAirport} → {flight.arrivalAirport}
        </div>
      </div>

      {/* centre – status badge */}
      <div>
        <span
          className={`text-xs font-semibold px-2 py-1 rounded-full whitespace-nowrap ${statusBadge[flight.status]}`}
        >
          {flight.status}
        </span>
      </div>

      {/* right block – weather */}
      <div className="text-right">
        <div className="text-lg font-semibold text-gray-800">
          {flight.weather.temp}&deg;F
        </div>
        {flight.weatherAlert ? (
          <div className="flex items-center justify-end text-yellow-600 font-semibold gap-1">
            <AlertTriangle size={14} /> Weather Alert
          </div>
        ) : (
          <div className="text-sm text-gray-700">
            {flight.weather.preciptype?.[0] ?? "—"}
          </div>
        )}
      </div>
    </div>
  );
};

export default FlightCard;
